export default function run() {
  console.log('Hello, world')
}
