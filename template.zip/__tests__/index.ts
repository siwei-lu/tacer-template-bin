test('1 + 2 = 3', () => {
  expect(1 + 2).toEqual(3)
})
