#!/usr/bin/env node
const run = require('../dist')
run()
